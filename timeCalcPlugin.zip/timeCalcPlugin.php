<?php
/**
* Plugin Name: Sophia's Time Calc
*
*/
?>
<!-- Sophia Scott Pet project html -->
<!doctype html>
<html lang="en">

<head>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <script src="jquery-3.6.1.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="petJS.js"></script>
    <link rel="stylesheet" href="petCss.css" />
</head>

<body>

    <h2>Schedule Time Calculator</h2>
    <p>This program will help you plan out your week!</p>
    <p>Click on the the spaces to enter the aproprate number of hours</p>
    <p>Before you begin be sure to customize(Edit button) the fixed number of hours for all other activities (Ex. sleep, meals, travel)</p>
    <p>When you are finshed hover your mouse over the bottom row boxes to see the updated number of hours</p>

    <label for="weekPicker">Select a week:</label>
    <input type="date" id="weekPicker" name="weekPicker" onchange="updateDates()">
    <!-- <input type="submit"> -->
    <br>
    <br>


    <button id="addRowButton">Add Activity</button>
    <table id="scheduleTable">
        <tr>
            <th id="empty"></th>
            <th id="headerM">Monday</th>
            <th id="headerTu">Tuesday</th>
            <th id="headerW">Wednesday</th>
            <th id="headerT">Thursday</th>
            <th id="headerF">Friday</th>
            <th id="headerS">Saturday</th>
            <th id="headerSu">Sunday</th>
        </tr>
        <script>
            function updateDates() {
                var weekPicker = document.getElementById("weekPicker");
                var chosenDate = new Date(weekPicker.value);
                var daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

                var headerCells = document.getElementsByTagName('th');
                for (var i = 1; i < headerCells.length; i++) {
                    var dayIndex = chosenDate.getDay() + i - 1;
                    if (dayIndex > 6) {
                        dayIndex -= 7;
                    }
                    headerCells[i].textContent = daysOfWeek[dayIndex] + ' (' + (chosenDate.getDate() + i - 1) + ')';
                }
            }
        </script>
        <!-- <tr>
            <th> </th>
            <th><span id="dateM"></span></th>
            <th><span id="dateTu"></span></th>
            <th><span id="dateW"></span></th>
            <th><span id="dateT"></span></th>
            <th><span id="dateF"></span></th>
            <th><span id="dateS"></span></th>
            <th><span id="dateSu"></span></th>
        </tr> -->
        <script>
            // function updateDates() {
            //     var weekPicker = document.getElementById("weekPicker");
            //     var selectedWeek = weekPicker.value;
            //     var startDate = getStartDateOfWeek(selectedWeek);
    
            //     var dateM = document.getElementById("dateM");
            //     dateM.textContent = formatDate(startDate);
            //     var dateTu = document.getElementById("dateTu");
            //     dateTu.textContent = formatDate(addDays(startDate, 1));
            //     var dateW = document.getElementById("dateW");
            //     dateW.textContent = formatDate(addDays(startDate, 2));
            //     var dateT = document.getElementById("dateT");
            //     dateT.textContent = formatDate(addDays(startDate, 3));
            //     var dateF = document.getElementById("dateF");
            //     dateF.textContent = formatDate(addDays(startDate, 4));
            //     var dateS = document.getElementById("dateS");
            //     dateS.textContent = formatDate(addDays(startDate, 5));
            //     var dateSu = document.getElementById("dateSu");
            //     dateSu.textContent = formatDate(addDays(startDate, 6));
            // }
    
            // function getStartDateOfWeek(weekValue) {
            //     var year = parseInt(weekValue.substring(0, 4));
            //     var week = parseInt(weekValue.substring(6));
            //     var date = new Date(year, 0, 1 + (week - 1) * 7);
            //     var day = date.getDay();
            //     var diff = date.getDate() - day + (day === 0 ? -6 : 1); // Adjust to Monday if Sunday
            //     return new Date(date.setDate(diff));
            // }
    
            // function formatDate(date) {
            //     var options = { month: 'long', day: 'numeric' };
            //     return date.toLocaleDateString('en-US', options);
            // }
    
            // function addDays(date, days) {
            //     var newDate = new Date(date);
            //     newDate.setDate(date.getDate() + days);
            //     return newDate;
            // }
        </script>
        <tr id="schoolhours">
            <td>School Hours:</td>
            <td id="SHM"> Click to Add Hours </td>
            <td id="SHTu"> Click to Add Hours </td>
            <td id="SHW"> Click to Add Hours </td>
            <td id="SHT"> Click to Add Hours </td>
            <td id="SHF"> Click to Add Hours </td>
            <td id="SHS"> Click to Add Hours </td>
            <td id="SHSu"> Click to Add Hours </td>
            <td><button onclick="deleteSchoolHoursRow()">Delete</button></td>
        </tr>
        <tr id="workhours">
            <td>Work Hours:</td>
            <td id="WHM"> Click to Add Hours </td>
            <td id="WHTu"> Click to Add Hours </td>
            <td id="WHW"> Click to Add Hours </td>
            <td id="WHT"> Click to Add Hours </td>
            <td id="WHF"> Click to Add Hours </td>
            <td id="WHS"> Click to Add Hours </td>
            <td id="WHSu"> Click to Add Hours </td>
            <td><button onclick="deleteWorkHoursRow()">Delete</button></td>
        </tr>
        <tr>
            <td id="allother">Hours for all other activities:</td>
            <td id="OtherM"> Click to Add Hours </td>
            <td id="OtherTu"> Click to Add Hours </td>
            <td id="OtherW"> Click to Add Hours </td>
            <td id="OtherT"> Click to Add Hours </td>
            <td id="OtherF"> Click to Add Hours </td>
            <td id="OtherS"> Click to Add Hours </td>
            <td id="OtherSu"> Click to Add Hours </td>
            <td><button id="editButton" onclick="editallother()">Edit</button></td>
            <script>
                // Function to handle editing additional activities for a specific day
                // function editallother() {
                //     var otherElement = document.getElementById("allother");
                //     var otherValue = prompt("Edit the average hours of all other daily time users, such as sleep, travel, or meals.");
                //     var totalHours = parseInt(otherValue);

                //     if (!isNaN(totalHours)) {
                //         otherElement.innerHTML = "Hours for all other activities: +" + totalHours;
                //         otherElement.style.background = "none";
                //     } else {
                //         otherElement.style.background = "red";
                //     }
                // }
                // function editallother() {
                //     var otherValue = prompt("Edit the average hours of all other daily time users, such as sleep, travel, or meals.");
                //     var totalHours = parseInt(otherValue);
                //     var otherElement = document.getElementById("allother");

                //     if (!isNaN(totalHours)) {
                //         otherElement.innerHTML = "Hours for all other activities: +" + totalHours;
                //         return totalHours;
                //     } else {
                //         return null;
                //     }
                // }



                // Attach click event to the "Edit" button
                // document.getElementById("editButton").addEventListener("click", editallother);

            </script>
        </tr>
        <script>
            //           function display() {
            //     document.getElementById("empty").style.display = "none";
            //   }
            // function updateDates() {
            //     var weekPicker = document.getElementById("weekPicker");
            //     var chosenDate = new Date(weekPicker.value);
            //     var daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

            //     var headerCells = document.getElementsByTagName('th');
            //     for (var i = 0; i < headerCells.length; i++) {
            //         var dayIndex = chosenDate.getDay() + i;
            //         if (dayIndex > 6) {
            //             dayIndex -= 7;
            //         }
            //         headerCells[i].textContent = daysOfWeek[dayIndex];
            //     }

            //     var dateM = document.getElementById("dateM");
            //     dateM.textContent = chosenDate.getDate();
            //     var dateTu = document.getElementById("dateTu");
            //     dateTu.textContent = chosenDate.getDate() + 1;
            //     var dateW = document.getElementById("dateW");
            //     dateW.textContent = chosenDate.getDate() + 2;
            //     var dateT = document.getElementById("dateT");
            //     dateT.textContent = chosenDate.getDate() + 3;
            //     var dateF = document.getElementById("dateF");
            //     dateF.textContent = chosenDate.getDate() + 4;
            //     var dateS = document.getElementById("dateS");
            //     dateS.textContent = chosenDate.getDate() + 5;
            //     var dateSu = document.getElementById("dateSu");
            //     dateSu.textContent = chosenDate.getDate() + 6;
            // }


            function deleteSchoolHoursRow() {
                var confirmation = confirm("Are you sure you want to delete this row?");
                if (confirmation) {
                    var row = document.getElementById("schoolhours");
                    row.parentNode.removeChild(row);
    
                    // Reset school hours values to 0
                    document.getElementById("shm").innerHTML = "0";
                    document.getElementById("SHTu").textContent = "0";
                    document.getElementById("SHW").textContent = "0";
                    document.getElementById("SHT").textContent = "0";
                    document.getElementById("SHF").textContent = "0";
                    document.getElementById("SHS").textContent = "0";
                    document.getElementById("SHSu").textContent = "0";
                }
            }
            function deleteWorkHoursRow() {
                var confirmation = confirm("Are you sure you want to delete this row?");
                if (confirmation) {
                    var row = document.getElementById("workhours");
                    row.parentNode.removeChild(row);
    
                    // Reset work hours values to 0
                    document.getElementById("WHM").textContent = "0";
                    document.getElementById("WHTu").textContent = "0";
                    document.getElementById("WHW").textContent = "0";
                    document.getElementById("WHT").textContent = "0";
                    document.getElementById("WHF").textContent = "0";
                    document.getElementById("WHS").textContent = "0";
                    document.getElementById("WHSu").textContent = "0";
                }
            }
        </script>
    <!-- </table>
    <table> -->
        <!-- <tr>
            <th id="empty"> </th>
            <th>Monday</th>
            <th>Tuseday</th>
            <th>Wednsday</th>
            <th>Thursday</th>
            <th>Friday</th>
            <th>Saturday</th>
            <th>Sunday</th>
        </tr> -->
        <tr>
            <td>Hours left left in the day:</td>
            <td id="LeftM">Hover to see total</td>
            <td id="LeftTu">Hover to see total</td>
            <td id="LeftW">Hover to see total</td>
            <td id="LeftT">Hover to see total</td>
            <td id="LeftF">Hover to see total</td>
            <td id="LeftS">Hover to see total</td>
            <td id="LeftSu">Hover to see total</td>
        </tr>

    </table>
    <button type="submit" onclick="saveTable()">Save</button>
    <div id="savedTables">
        <h3>Saved Tables</h3>
        <div id="message"></div>
        <table id="savedTable"></table>
        <button onclick="previousTable()">&#8249;</button>
        <button onclick="nextTable()">&#8250;</button>
        <button id="deleteButton" onclick="deleteCurrentTable()">Delete</button>
    </div>

    <script>
        var savedTables = [];
        var currentTableIndex = -1;

        function saveTable() {
            var scheduleTable = document.getElementById("scheduleTable").cloneNode(true);
            var date = document.getElementById("weekPicker").value;

            var deleteButtons = scheduleTable.querySelectorAll("button");
            for (var i = 0; i < deleteButtons.length; i++) {
                deleteButtons[i].parentNode.removeChild(deleteButtons[i]);
            }

            var editButton = scheduleTable.querySelector("#editButton");
            if (editButton) {
                editButton.parentNode.removeChild(editButton);
            }

            savedTables.push({
                date: date,
                table: scheduleTable
            });

            showSaveMessage();
        }

        function showSaveMessage() {
            var message = document.getElementById("message");
            message.textContent = "Table has been saved.";

            setTimeout(function () {
                message.textContent = "";
            }, 3000);
        }

        function previousTable() {
            if (currentTableIndex > 0) {
                currentTableIndex--;
                displaySavedTable();
            }
        }

        function nextTable() {
            if (currentTableIndex < savedTables.length - 1) {
                currentTableIndex++;
                displaySavedTable();
            }
        }

    
        function displaySavedTable() {
        var savedTable = document.getElementById("savedTable");
        savedTable.innerHTML = "";

        var currentTableData = savedTables[currentTableIndex];

        var currentTable = currentTableData.table;
        savedTable.appendChild(currentTable.cloneNode(true));

        updateDeleteButton();
    }

    function updateDeleteButton() {
        var deleteButton = document.getElementById("deleteButton");

        // Remove existing delete button if it exists
        if (deleteButton) {
            deleteButton.parentNode.removeChild(deleteButton);
        }

        deleteButton = document.createElement("button");
        deleteButton.id = "deleteButton";
        deleteButton.textContent = "Delete";
        deleteButton.onclick = function() {
            deleteCurrentTable();
        };

        var savedTablesDiv = document.getElementById("savedTables");
        savedTablesDiv.appendChild(deleteButton);
    }

    function deleteCurrentTable() {
        var confirmation = confirm("Are you sure you want to delete this saved table?");
        if (confirmation && currentTableIndex >= 0 && currentTableIndex < savedTables.length) {
            savedTables.splice(currentTableIndex, 1);
            currentTableIndex = Math.min(currentTableIndex, savedTables.length - 1);
            displaySavedTable();
            showDeleteMessage();
        }
    }

    function showDeleteMessage() {
        var message = document.getElementById("message");
        message.textContent = "The saved table has been deleted.";

        setTimeout(function () {
            message.textContent = "";
        }, 3000);
    }
    </script>
    <!-- <button onclick="deleteSavedTable(this)">Delete</button> -->
        <!-- <script>
         function deleteSavedTable(button) {
  var confirmation = confirm("Are you sure you want to delete this saved table?");
  if (confirmation) {
    var table = button.parentNode.parentNode.parentNode;
    table.parentNode.removeChild(table);
  }
}


        </script> -->
    <!-- <button type="submit" onclick="saveTable()">Save</button>

    <h3 id="savedHeading" style="display: none;">Saved</h3>
    <div id="savedTablesContainer"></div>

    <script>
        var savedTables = [];
        var currentTableIndex = -1;

                function saveTable() {
            var currentDate = new Date();
            var formattedDate = currentDate.toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
            });

            var tableClone = document.getElementById("scheduleTable").cloneNode(true);
            var deleteButtons = tableClone.getElementsByTagName("button");
            for (var i = 0; i < deleteButtons.length; i++) {
                deleteButtons[i].remove();
            }
            var editButton = tableClone.querySelector("#editButton");
            if (editButton) {
                editButton.remove();
            }

            savedTables.push({
                date: formattedDate,
                table: tableClone.innerHTML
            });

            showSavedTables();
        }


        function showSavedTables() {
            var savedHeading = document.getElementById("savedHeading");
            var savedTablesContainer = document.getElementById("savedTablesContainer");
            savedTablesContainer.innerHTML = "";

            if (savedTables.length > 0) {
                savedHeading.style.display = "block";

                for (var i = 0; i < savedTables.length; i++) {
                    var table = document.createElement("table");
                    table.innerHTML = savedTables[i].table;
                    table.style.display = i === currentTableIndex ? "block" : "none";
                    savedTablesContainer.appendChild(table);
                }

                if (savedTables.length > 1) {
                    var prevButton = document.createElement("button");
                    prevButton.textContent = "Previous";
                    prevButton.onclick = function () {
                        currentTableIndex = (currentTableIndex - 1 + savedTables.length) % savedTables.length;
                        showSavedTables();
                    };
                    savedTablesContainer.appendChild(prevButton);

                    var nextButton = document.createElement("button");
                    nextButton.textContent = "Next";
                    nextButton.onclick = function () {
                        currentTableIndex = (currentTableIndex + 1) % savedTables.length;
                        showSavedTables();
                    };
                    savedTablesContainer.appendChild(nextButton);
                }
            } else {
                savedHeading.style.display = "none";
            }
        }
    </script> -->
</body>

</html>